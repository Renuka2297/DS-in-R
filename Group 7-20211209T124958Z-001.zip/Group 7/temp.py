import streamlit as st
from sklearn.cluster import KMeans
import pandas as pd
st.title('Model Deployment: Clustering')
st.sidebar.header('User Input Parameters')

def user_input_features():
    Age= st.sidebar.number_input("Age")
    Education = st.sidebar.selectbox('Education(Select 1.0 for Post Graduate & 0.0 for Under Graduate)',('1.0','0.0'))
    Marital_Status = st.sidebar.selectbox('Maritial Status(1.Together,2.Single)',('1.0','0.0'))
    Children=st.sidebar.number_input("No. of Children")
    Income = st.sidebar.number_input("Insert Income")
    Total_spent = st.sidebar.number_input("Amount on shopping")
    Recency = st.sidebar.number_input("Recency")
    Total_no_purchase=st.sidebar.number_input("Insert No. of purchases")
    Complain = st.sidebar.selectbox('Complain',('1.0','0.0'))
    TotalAcceptedCmp  = st.sidebar.selectbox('Compaign Accepted',('1.0','0.0'))
        
    data = {'Index':1,           
            'Education':Education, 
            'Marital_Status':Marital_Status, 
            'Income':Income,
            'Recency':Recency, 
            'Complain':Complain,
            'Age':Age,
            'Children':Children, 
            'Total_spent':Total_spent, 
            'Total_no_purchase':Total_no_purchase,
            'TotalAcceptedCmp':TotalAcceptedCmp
            }
    features = pd.DataFrame(data,index=[0])
    return features 
        
df = user_input_features()
st.subheader('User Input parameters')
st.write(df)

model_data = pd.read_csv("filtered_data.csv",index_col=False)
model_data = model_data.dropna()

KM_clusters = KMeans(4, random_state=42)
KM_clusters.fit(model_data)

test=st.button("Press for prediction")
st.write(test)
prediction=0
if(test == 1):
    prediction = KM_clusters.predict(df)
    st.write(prediction)
    
